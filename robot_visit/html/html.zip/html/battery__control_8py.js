var battery__control_8py =
[
    [ "battery", "classbattery__control_1_1battery.html", "classbattery__control_1_1battery" ],
    [ "BT", "battery__control_8py.html#a0a93c96d16da9eceb1b7be6552f0d610", null ],
    [ "CAPACITY_", "battery__control_8py.html#a9e3985f22d1b0ad54d19fb6b9023ab96", null ]
];
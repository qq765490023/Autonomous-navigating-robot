var annotated_dup =
[
    [ "battery_control", null, [
      [ "state-decision-maker:", "md__root_ros_ws_src_robot_visit_scripts_readme.html#autotoc_md3", null ],
      [ "control:", "md__root_ros_ws_src_robot_visit_scripts_readme.html#autotoc_md4", null ],
      [ "move:", "md__root_ros_ws_src_robot_visit_scripts_readme.html#autotoc_md5", null ],
      [ "armor:", "md__root_ros_ws_src_robot_visit_scripts_readme.html#autotoc_md6", null ],
      [ "battery control:", "md__root_ros_ws_src_robot_visit_scripts_readme.html#autotoc_md7", null ],
      [ "battery", "classbattery__control_1_1battery.html", "classbattery__control_1_1battery" ]
    ] ],
    [ "move", null, [
      [ "Move_manager", "classmove_1_1_move__manager.html", "classmove_1_1_move__manager" ]
    ] ],
    [ "state_decision_maker", null, [
      [ "charging", "classstate__decision__maker_1_1charging.html", "classstate__decision__maker_1_1charging" ],
      [ "checking", "classstate__decision__maker_1_1checking.html", "classstate__decision__maker_1_1checking" ],
      [ "decision_maker", "classstate__decision__maker_1_1decision__maker.html", "classstate__decision__maker_1_1decision__maker" ],
      [ "wait_map", "classstate__decision__maker_1_1wait__map.html", "classstate__decision__maker_1_1wait__map" ],
      [ "wander", "classstate__decision__maker_1_1wander.html", "classstate__decision__maker_1_1wander" ]
    ] ]
];
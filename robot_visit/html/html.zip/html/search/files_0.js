var searchData=
[
  ['battery_5fcontrol_2epy_29',['battery_control.py',['../battery__control_8py.html',1,'']]]
];

var searchData=
[
  ['run_17',['run',['../classbattery__control_1_1battery.html#a6207c8a2f67fd06952504509a4bcc83e',1,'battery_control::battery']]]
];

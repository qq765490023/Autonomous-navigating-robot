var searchData=
[
  ['move_5fmanager_26',['Move_manager',['../classmove_1_1_move__manager.html',1,'move']]]
];

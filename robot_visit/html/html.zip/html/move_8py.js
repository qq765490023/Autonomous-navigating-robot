var move_8py =
[
    [ "Move_manager", "classmove_1_1_move__manager.html", "classmove_1_1_move__manager" ],
    [ "log_level", "move_8py.html#a83c2141da132950a2fb056420e0dfb48", null ],
    [ "NODE_MOVE", "move_8py.html#a15926b64864786fa357a92ecdeddb022", null ],
    [ "server", "move_8py.html#a661b16825dd831303096cbac32f0ca40", null ]
];